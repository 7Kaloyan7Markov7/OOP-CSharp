﻿using ClockLib;
using System;
using System.Linq;
using System.Media;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AlarmClockApp
{
    public partial class MainWindow : Window
    {
        private (int hour, int minute, int second) startTime;
        private (int hour, int minute, int second) currentTime;
        private Random rand = new Random();
        private double ringAfter;
        private bool hasRung = false;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void ucDigitalClock_ClockStarted(object sender, EventArgs e)
        {
            ClockTickArgs args = (ClockTickArgs)e;
            startTime = args.ClockTick;
            hasRung = false;

            string raw = tbxRingAfter.Text.Replace(',', '.');
            if (double.TryParse(raw, System.Globalization.NumberStyles.Any,
                    System.Globalization.CultureInfo.InvariantCulture, out double ra))
                ringAfter = ra;

            tbxOutput.AppendText(
                $"Start time: {startTime.hour:D2}:{startTime.minute:D2}:{startTime.second:D2}\n");
        }

        private void ucDigitalClock_TimeUpdated(object sender, EventArgs e)
        {
            ClockTickArgs args = (ClockTickArgs)e;
            currentTime = args.ClockTick;

            if (currentTime.second % 2 == 0)
                tbxBeepIndicator.AppendText(rand.Next(10, 51) + " ");

            double startTotalSeconds =
                startTime.hour * 3600 + startTime.minute * 60 + startTime.second;
            double currentTotalSeconds =
                currentTime.hour * 3600 + currentTime.minute * 60 + currentTime.second;
            double elapsedMinutes = (currentTotalSeconds - startTotalSeconds) / 60.0;

            if (ringAfter > 0 && elapsedMinutes >= ringAfter && !hasRung)
            {
                hasRung = true;
                tbxBeepIndicator.AppendText("\nStart ringing");
                SystemSounds.Beep.Play();
            }
        }

        private void btnFindDistinct_Click(object sender, RoutedEventArgs e)
        {
            var numbers = tbxBeepIndicator.Text
                .Split(new char[] { ' ', '\n', '\r', '\t' }, StringSplitOptions.RemoveEmptyEntries)
                .Where(s => int.TryParse(s, out _))
                .Select(int.Parse)
                .ToList();

            var distinct = numbers.Distinct().OrderBy(n => n);
            var frequency = numbers.GroupBy(n => n).OrderByDescending(g => g.Key);

            tbxOutput.Text = "Distinct numbers\n";
            tbxOutput.Text += string.Join(" ", distinct) + "\n";
            tbxOutput.Text += "Frequency\n";
            foreach (var g in frequency)
                tbxOutput.Text += $"Number:{g.Key} found {g.Count()} times.\n";
        }
    }
}