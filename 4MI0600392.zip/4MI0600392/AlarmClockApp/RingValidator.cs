﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using System.Windows.Controls;

namespace AlarmClockApp
{
    public class RingValidator : ValidationRule
    {
        public double MinRings { get; set; }
        public double MaxRings { get; set; }

        public override ValidationResult Validate(object value, CultureInfo cultureInfo)
        {
            string str = value?.ToString().Replace(',', '.');
            if (double.TryParse(str, NumberStyles.Any, CultureInfo.InvariantCulture, out double result))
            {
                if (result >= MinRings && result <= MaxRings)
                    return ValidationResult.ValidResult;
                return new ValidationResult(false, $"Стойността трябва да е в [{MinRings}, {MaxRings}]");
            }
            return new ValidationResult(false, "Невалидно число");
        }
    }
}
