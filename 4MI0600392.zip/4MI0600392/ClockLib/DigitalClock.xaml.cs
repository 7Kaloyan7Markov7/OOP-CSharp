﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace ClockLib
{
    public partial class DigitalClock : UserControl
    {
        public event EventHandler ClockStarted;
        public event EventHandler TimeUpdated;

        private DispatcherTimer timer;

        public DigitalClock()
        {
            InitializeComponent();
            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(1);
            timer.Tick += Timer_Tick;
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            DateTime now = DateTime.Now;
            tbkTime.Text = now.ToString("HH:mm:ss");
            TimeUpdated?.Invoke(this, new ClockTickArgs(now.Hour, now.Minute, now.Second));
        }

        private void btnStart_Click(object sender, RoutedEventArgs e)
        {
            timer.Start();
            DateTime now = DateTime.Now;
            ClockStarted?.Invoke(this, new ClockTickArgs(now.Hour, now.Minute, now.Second));
        }

        private void btnStop_Click(object sender, RoutedEventArgs e)
        {
            timer.Stop();
        }

        private void btnReset_Click(object sender, RoutedEventArgs e)
        {
            tbkTime.Text = string.Empty;
        }
    }
}
