﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClockLib
{
    public class ClockTickArgs : EventArgs
    {
        public (int hour, int minute, int second) ClockTick { get; set; }

        public ClockTickArgs(int hour, int minute, int second)
        {
            ClockTick = (hour, minute, second);
        }
    }
}
